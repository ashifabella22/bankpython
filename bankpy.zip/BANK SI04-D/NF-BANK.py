
Data_List_Trf = open("List_Transfer.txt")
Data_List_Nsb = open("List_Nasabah.txt")

Data_A = []
Data_B = []
Data_C = []
Data_D = []
Data_Nama = []
Data_Rekening = []
Data_Saldo = []
Data_Cek_Saldo = []
Data_Raw_Saldo =[]
Data_Raw = []
Data_Transfer = []

for a in Data_List_Trf:
    Data_Raw.append(a.strip())
for b in Data_Raw:
    Data_Transfer.append(b.split(","))
for c in range(len(Data_Transfer)):
  if Data_Transfer[c][1] not in Data_C:
    Data_C.append(Data_Transfer[c][1])

for d in Data_List_Nsb:
    Data_A.append(d.strip())
    Data_Raw_Saldo.append(d.strip())
for e in Data_Raw_Saldo:
    Data_Cek_Saldo.append(e.split(","))
for e in Data_A:
    Data_B.append(e.split(","))
for f in range(len(Data_B)):
    if Data_Cek_Saldo[f][0] not in Data_B:
        Data_B.append(Data_Cek_Saldo[f][0])
    Data_Rekening.append(Data_B[f][0])
    Data_Nama.append(Data_B[f][1])
    Data_Saldo.append(eval(Data_B[f][2]))

#------------------------------------------------#

#Membuat Convert
Data_Uang = dict(zip(Data_Rekening, Data_Saldo))
Data_Nasabah = dict(zip(Data_Rekening, Data_Nama))
#------------------------------------------------#

#Membuat Menu Bank
def Menubank():
    print("")
    print(" *WELCOME TO NF BANK*       ")
    print("MENU:")
    print("[1] Customer Account        ")
    print("[2] Deposit Money             ")
    print("[3] Withdraw Money              ")
    print("[4] Transfer                  ")
    print("[5] Check Transfer Data  ")
    print("[6] Check Balance                  ")
    print("[7] Exit/Quit                  ")
    print("")
Menubank()
#------------------------------------------------#

#Membuat Fungsi Setiap Menu
while True: 
    PilihMenu = input("Select your choice menu: ")

    if PilihMenu == '1':

        Nama = input("Input your name: ")
        Jml_Setoran_Awal = eval(input("Enter the value you want to deposit: "))

        import random, string
        NomorRekening =  ''.join(random.choice(string.digits) for _ in range(3))
        print("Account with", NomorRekening, ",Name", Nama, "Success.\n")

        Data_Nama.append(Nama)
        Data_Saldo.append(Jml_Setoran_Awal)
        Data_Rekening.append(NomorRekening)
        Data_Uang[NomorRekening] = Jml_Setoran_Awal
        Data_Nasabah[NomorRekening] = Nama

        Menubank()
    #------------------------------------------------#

    elif PilihMenu == '2':

        print("***** DEPOSIT *****")
        Rekening = input("Input your Account ID: ")
        Nominal_Setor = eval(input("Input value to Deposit: "))

        if Rekening.upper() in Data_Rekening:
            print("Deposit", Nominal_Setor, "To Account ID", Rekening, "Success.\n")
            Pertambahan = Data_Uang[Rekening.upper()] + Nominal_Setor
            Data_Uang[Rekening.upper()] = Pertambahan
        else:
            print("Your Account ID is not available.\n")

        Menubank()
    #------------------------------------------------#

    elif PilihMenu == '3':

        print("***** WITHDRAW *****")
        Rekening = input("Input your Account ID: ")
        Jml_Nominal_Tarik = eval(input("Input value to Withdraw: "))

        if Rekening.upper() in Data_Rekening:
            if Jml_Nominal_Tarik < Data_Uang[Rekening.upper()]:
                Pengurangan = Data_Uang[Rekening.upper()] - Jml_Nominal_Tarik
                Data_Uang[Rekening.upper] = Pengurangan
                print("Withdraw", Jml_Nominal_Tarik, "From Account ID", Rekening, "Success.\n")
                Data_Uang[Rekening.upper()] = Pengurangan
            else:
                print("Not enough balance.\n")
        else:
            print("Account ID is not Available. Withdraw failed.\n")

        Menubank()
    #------------------------------------------------#

    elif PilihMenu == '4':

        print("***** TRANSFER *****")
        Rekening = input("Input your Account ID: ")
        Rekening_Tujuan = input("Input other Account ID: ")
        Jml_Nominal_Trf = eval(input("Input value to Transfer: "))

        if Rekening.upper() in Data_Rekening:
            if Rekening_Tujuan.upper() in Data_Rekening:
                if Jml_Nominal_Trf <= Data_Uang[Rekening.upper()]:
                    Pertambahan = Data_Uang[Rekening_Tujuan.upper()] + Jml_Nominal_Trf
                    Pengurangan = Data_Uang[Rekening.upper()] - Jml_Nominal_Trf
                    Data_Uang[Rekening.upper()] = Pengurangan
                    Data_Uang[Rekening_Tujuan.upper()] = Pertambahan
                    print("Transfer", Jml_Nominal_Trf, "from Account ID", Rekening, "to Account ID" , Rekening_Tujuan,"Success.\n")

                    import random, string
                    Transfer = "TRF" + ''.join(random.choice(string.digits) for _ in range(3))
                    Data_Transfer.append([Transfer, Rekening.upper(), Rekening_Tujuan.upper(), Jml_Nominal_Trf])
                    Data_C.append(Rekening.upper())
                else:
                    print("Not enough balance. \n")
            else:
                print("Account ID not found. Failed to Transfer.\n")
        else:
            print("Your Account ID not found. Failed to Transfer.\n")

        Menubank()
    #------------------------------------------------#

    elif PilihMenu == '5':

        print("***** TRANSFER DATA *****")
        Rekening = input("Input your Account ID: ")
        
        if Rekening.upper() in Data_Rekening:
          if Rekening.upper() in Data_C:
                for wow in range(len(Data_Transfer)):
                    if Rekening.upper() == Data_Transfer[wow][1]:
                        print(Data_Transfer[wow][0], Data_Transfer[wow][1], Data_Transfer[wow][2], Data_Transfer[wow][3])
                print("\n")
          else:
            print("There's no Data Showed.\n")
        else:
            print("Your Account ID not found.\n")

        Menubank()
    #------------------------------------------------#

    elif PilihMenu == '6':

        print("***** CHECK BALANCE *****")
        Rekening = input("Input your Account ID: ")
        
        if Rekening.upper() in Data_Rekening:
          if Rekening.upper() in Data_B:
                for wow in range(len(Data_Cek_Saldo)):
                    if Rekening.upper() == Data_Cek_Saldo[wow][0]:
                        print(Data_Cek_Saldo[wow][0], Data_Cek_Saldo[wow][1], "| Balance: ", Data_Cek_Saldo[wow][2])
                print("\n")
          else:
            print("There's no Data Showed.\n")
        else:
            print("Your Account ID not found.\n")

        Menubank()
    #------------------------------------------------#

    elif PilihMenu == '7':

        print("Thanks for your Visit")
        Nasabah = open("List_Nasabah.txt", "+w")

        for tulis in range(len(Data_Rekening)):
          Nasabah.write(str(Data_Rekening[tulis])+ "," + str(Data_Nama[tulis]) + "," + str(Data_Uang[Data_Rekening[tulis]])+ "\n")

        Nasabah = open("List_Transfer.txt", "+w")
        for tulis in range(len(Data_Transfer)):
            Nasabah.write(str(Data_Transfer[tulis][0])+","+str(Data_Transfer[tulis][1])+","+str(Data_Transfer[tulis][2])+","+str(Data_Transfer[tulis][3])+"\n")

        Nasabah.close()
        Data_List_Trf.close()
        Data_List_Nsb.close()
        break
    else:
        print("Your choice is wrong, Try Again.")
    #------------------------------------------------#
